<div>

<form name='form' action='mysql_settings_insert.php' method='post'>

<p><label>Введите название страницы - page <br />
<input type="text" name="page" id="page" size="20" value="index_adm" />
</label></p>

<p><label>Заголовок - title <br />
<input type="text" name="title" id="title" size="115" value="АН ПРАГА. Операции с недвижимостью в Коряжме. Юридические услуги." />
</label></p>

<p><label>Введите краткое описание страницы description для поисковых систем - meta_d <br />
<textarea name="meta_d" id="meta_d" cols="100" rows="2">
ООО Агентство недвижимости "Прага": покупка, продажа, аренда, обмен недвижимости в Коряжме. Независимая оценка, юридические услуги.
</textarea>
</label></p>

<p><label>Введите ключевые слова для поиска - meta_k <br />
<textarea name="meta_k" id="meta_k" cols="100" rows="2">
Агентство недвижимости ПРАГА, Прага, прага, недвижимость, Земцов, Коряжма, Пушкина, сдам, обменяю, сниму, квартиру, комнату, продажа, обмен, снять, обменять, услуги, цена, виды деятельности, помощь, оформление, подбор вариантов, сделка, сопровождение
</textarea>
</label></p>

<p><label>Введите заголовок - h1 - для страницы<br />
<input type="text" name="title" id="title" size="115" value="Агентства недвижимости города Коряжмы предлагают:<br /> <em>однокомнатные квартиры</em>" />
</label></p>

<p><label>Введите заголовок - h2 - для страницы<br />
<input type="text" name="title" id="title" size="115" value="В продаже с <span>" />

</label></p>

<p><label>Введите дату - date <br />
<input type="text" name="date" id="date" size="20" value="31" />
</label></p>

<p><label>Введите месяц - month в формате<br />
<input type="text" name="month" id="month" size="20" value="сентября 2013</span>" />
</label></p>

<p><label>Введите полный текст страницы - text<br />
<textarea name="text" id="text" cols="100" rows="5"></textarea>
</label></p>

<p><label>
<input type="submit" name="submit" id="submit" value="Занести в базу" />
</label></p>

</form>

</div>
