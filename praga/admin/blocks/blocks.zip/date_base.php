<?php
$db = mysql_connect ("localhost","nikart_realty","arteeva69");
mysql_select_db ("nikart_realty",$db);
?>