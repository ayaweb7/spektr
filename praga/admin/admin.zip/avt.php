<h2 align="center">Вы пытаетесь войти в ограниченную часть сайта. <br />
Для этого надо получить у администратора сайта логин и пароль.</h2>

<form action='index_adm.php' method='post'>
	<table cellspacing='0' cellpadding='1' width='100%' class='tableborder'>
    	        
      <tr>
          <td colspan='2' valign='top'><span style='width:60px; padding-left:4px;'>Логин</span></td>
		  <td>	<input type='text' name='login' size='15' autofocus /></td>
      </tr>
      
      <tr>
		  <td colspan='2' valign='top'><span style='width:60px; padding-left:4px;'>Пароль</span></td>
		  <td><input type='text' name='pass' size='15' /></td>
      </tr>
     

<tr><td colspan='2'>&nbsp;</td><td><input type='submit' name='set_filter' value='Войти' style='margin-left:30px;'/></td></tr>

</table>

</form>
